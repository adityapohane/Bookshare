import {
    Card,
    Input,
    Checkbox,
    Button,
    Typography,
  } from "@material-tailwind/react";
   
  export default function Asettingbtn() {
    return (  
     
    <>
      <div className="  bg-[#F0ECEC] w-full  h-screen  pt-10  ">
         <div className="flex justify-center  items-center xl:space-x-8 sm:space-x-4 space-x-4">
            
                    <Button className="" >My Details</Button>
           <Button>Change Password</Button>
        
            </div>
      </div>
      </>
   )
  }