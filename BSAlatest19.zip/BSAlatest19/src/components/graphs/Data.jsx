export const UserData = [
  {
    id: 1,
    student: "Jan",
    Persent: 60,
    
  },
  {
    id: 2,
    student: "Feb",
    Persent: 70,
  },
  {
    id: 3,
    student: "March",
    Persent: 50,
  },
  {
    id: 4,
    student: "April",
    Persent: 65,
  },
  {
    id: 5,
    student: "May",
    Persent: 55,
  },
];
