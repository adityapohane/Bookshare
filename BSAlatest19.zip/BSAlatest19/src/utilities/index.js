export const socials = [
    {
      name: 'twitter',
      url: './twitter.png',

    },
    {
      name: 'linkedin',
      url: './linkedin.png',
    },
    {
      name: 'instagram',
      url: './instagram.png',
    },
    {
      name: 'facebook',
      url: './facebook.png',
    },
  ];


export const whyyou = [
  {
    title:'SEND DONATION',  
    subtitle:"Remember that the happiest people are not those getting more but those giving more.hvhvjhjh",
    img:"./images/senddonation.jpeg",
    btn:"CLICK"
  },
  {
    title:'JOIN US',  
    subtitle:"Get involved. You don't want to look  back on your life and realize that   you successfully managed to   stay out of it.",
    img:"./images/Joinus.jpeg",
    btn:"CLICK"
  },
  {
    title:'EVENTS',  
    subtitle:"You have brains in your head.  You have feet in your shoes.   You can steer yourself any    direction you choose.",
    img:"./images/Events.jpeg",
    btn:"CLICK"
  },
]